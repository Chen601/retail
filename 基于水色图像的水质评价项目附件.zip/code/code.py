from PIL import Image
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report,confusion_matrix
import os
import re
img_name_1=[]
img_name_2=[]
img_name_3=[]
img_name_4=[]
img_name_5=[]
def get_path():
    path='C:/Users/Administrator/Desktop/images'
    name=os.listdir(path)
    for i in name:
        if re.findall('1_\d+\.jpg$',i)!=[]:
            img_name_1.append(i)
        if re.findall('2_\d+\.jpg$',i)!=[]:
            img_name_2.append(i)
        if re.findall('3_\d+\.jpg$',i)!=[]:
            img_name_3.append(i)
        if re.findall('4_\d+\.jpg$',i)!=[]:
            img_name_4.append(i)
        if re.findall('5_\d+\.jpg$',i)!=[]:
            img_name_5.append(i)
    return [img_name_1,img_name_2,img_name_3,img_name_4,img_name_5]
get_path()
def yijieju(data):
    return np.mean(data)
def erjieju(data):
    return np.std(data)
def sanjieju(data):
    mid=np.mean((data-data.mean())**3)
    return np.sign(mid)*abs(mid)**(1/3)
data=[]
target=[]
wenjian=[img_name_1,img_name_2,img_name_3,img_name_4,img_name_5]
for j in range(5):
    for i in wenjian[j]:
        im=Image.open('C:/Users/Administrator/Desktop/images/{}'.format(i))
        M,N=im.size
        region=im.crop((M/2-50,N/2-50,M/2+50,N/2+50))#截取图片中间区域
        region.save('C:/Users/Administrator/Desktop/images_1/{}'.format(i))
        a=np.array(region)#生成图片RGB矩阵
        da=[yijieju(a[:,:,0]),yijieju(a[:,:,1]),yijieju(a[:,:,2]),erjieju(a[:,:,0]),erjieju(a[:,:,1]),erjieju(a[:,:,2]),sanjieju(a[:,:,0]),sanjieju(a[:,:,1]),sanjieju(a[:,:,2])]
        data.append(da)
        target.append(j+1)
x_train,x_test,y_train,y_test=train_test_split(data,target,test_size=0.2)
model=DecisionTreeClassifier().fit(x_train,y_train)
pre=model.predict(x_test)
print(confusion_matrix(y_test,pre))
print(classification_report(y_test,pre))
